import os, pickle
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

DATA = "data/student_performance.csv"
MODEL = "models/student_performance_model.pkl"

df = pd.read_csv(DATA)
features = ["attendance","assignment_score","internal_score","study_hours","previous_score","absences"]
X = df[features]
y = df["final_score"]

# With a small demonstration dataset, train/test split is mainly illustrative.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = RandomForestRegressor(n_estimators=200, random_state=42)
model.fit(X_train, y_train)

pred = model.predict(X_test)
print("MAE:", round(mean_absolute_error(y_test, pred), 2))
print("R2:", round(r2_score(y_test, pred), 2))

os.makedirs("models", exist_ok=True)
with open(MODEL, "wb") as f:
    pickle.dump(model, f)

print("Saved:", MODEL)
