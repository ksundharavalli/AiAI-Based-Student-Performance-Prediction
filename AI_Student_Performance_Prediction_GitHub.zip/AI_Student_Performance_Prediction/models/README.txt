Run `python train_model.py` after installing requirements to generate the model file.
