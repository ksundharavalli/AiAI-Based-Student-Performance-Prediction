# AI-Based Student Performance Prediction

An educational machine-learning project that predicts a student's expected final score using academic and attendance-related inputs.

## Features

- Predicts final score from student data
- Uses Random Forest Regression
- Simple Flask web interface
- Includes a sample CSV dataset
- Classifies prediction as High Performance, Average Performance, or Needs Improvement

## Project Structure

```text
AI_Student_Performance_Prediction/
├── app.py
├── train_model.py
├── requirements.txt
├── README.md
├── data/
│   └── student_performance.csv
├── models/
│   └── student_performance_model.pkl
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Inputs

- Attendance percentage
- Assignment score
- Internal assessment score
- Study hours per week
- Previous exam score
- Number of absences

## Installation

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

Install packages:

```bash
pip install -r requirements.txt
```

## Train the Model

```bash
python train_model.py
```

This creates `models/student_performance_model.pkl`.

## Run the Web App

```bash
python app.py
```

Then open the local address shown by Flask in your browser.

## GitHub Upload

Create a new repository on GitHub, then run:

```bash
git init
git add .
git commit -m "Initial student performance prediction project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Replace `YOUR_GITHUB_REPOSITORY_URL` with your repository URL.

## Educational Note

This project is intended for learning and demonstration. Predictions depend on the quality and representativeness of the training data and should not be used as the sole basis for decisions about students.
