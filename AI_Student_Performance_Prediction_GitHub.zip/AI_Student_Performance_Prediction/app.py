from flask import Flask, render_template, request
import os, pickle

app = Flask(__name__)
MODEL_PATH = os.path.join("models", "student_performance_model.pkl")

def predict_score(attendance, assignment, internal, study_hours, previous, absences):
    # Fallback model if the saved model is unavailable.
    return (
        0.20 * attendance +
        0.15 * assignment +
        0.20 * internal +
        1.5 * study_hours +
        0.25 * previous -
        0.35 * absences
    )

model = None
if os.path.exists(MODEL_PATH):
    try:
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)
    except Exception:
        model = None

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    category = None
    if request.method == "POST":
        try:
            values = [
                float(request.form["attendance"]),
                float(request.form["assignment"]),
                float(request.form["internal"]),
                float(request.form["study_hours"]),
                float(request.form["previous"]),
                float(request.form["absences"]),
            ]
            if model:
                prediction = float(model.predict([values])[0])
            else:
                prediction = predict_score(*values)
            prediction = max(0, min(100, prediction))
            if prediction >= 75:
                category = "High Performance"
            elif prediction >= 50:
                category = "Average Performance"
            else:
                category = "Needs Improvement"
        except (ValueError, KeyError):
            prediction = "Please enter valid values."
    return render_template("index.html", prediction=prediction, category=category)

if __name__ == "__main__":
    app.run(debug=True)
